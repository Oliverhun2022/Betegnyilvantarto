import { Component } from '@angular/core';

@Component({
  selector: 'app-betegnyilvantarto',
  standalone: true,
  imports: [],
  templateUrl: './betegnyilvantarto.component.html',
  styleUrl: './betegnyilvantarto.component.css'
})
export class BetegnyilvantartoComponent {

}
