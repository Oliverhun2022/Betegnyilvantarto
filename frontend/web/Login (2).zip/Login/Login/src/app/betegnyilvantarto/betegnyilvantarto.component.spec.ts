import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BetegnyilvantartoComponent } from './betegnyilvantarto.component';

describe('BetegnyilvantartoComponent', () => {
  let component: BetegnyilvantartoComponent;
  let fixture: ComponentFixture<BetegnyilvantartoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BetegnyilvantartoComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(BetegnyilvantartoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
