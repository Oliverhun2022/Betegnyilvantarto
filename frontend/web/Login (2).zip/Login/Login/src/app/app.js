const express = require('express');

const app = express();
const PORT = process.env.PORT || 3000;

app.get('/betegnyilvantarto', (req, res) => {
    res.send('Betegnyilvantarto oldal tartalma');
});


app.get('*', (req, res) => {
    res.status(404).send('404 - Az oldal nem található');
});

app.listen(PORT, () => {
    console.log(`A szerver fut a ${PORT}-es porton...`);
});
