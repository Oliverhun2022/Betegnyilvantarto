import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from './login.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  isSignDivVisiable: boolean = true;

  signUpObj: SignUpModel = new SignUpModel();
  password!: string;
  email: string | undefined;

  model: any = {};
  getData: boolean | undefined
  constructor(private loginService: LoginService, private router: Router) {
    
  }


  onRegister() {
    debugger;
    const localUser = localStorage.getItem('angular17users');
    if(localUser != null) {
      const users = JSON.parse(localUser);
      users.push(this.signUpObj);
      localStorage.setItem('angular17users', JSON.stringify(users))
    } else {
      const users = [];
      users.push(this.signUpObj);
      localStorage.setItem('angular17users', JSON.stringify(users))
    }
    alert("Regisztráció sikeres!")
  }

  onLogin() {
    debugger;
    const localUsers = localStorage.getItem('angular17users');
    if(localUsers != null) {
      const users = JSON.parse(localUsers);

      const isUserPresent = users.find( (user:SignUpModel) => user.email == this.email && user.password == this.password)
      if(isUserPresent != undefined) {
        alert("Felhasználó keresése...");
        localStorage.setItem('loggedUser', JSON.stringify(isUserPresent));
        this.router.navigateByUrl('/dashboard');
      } else {
        alert("A felhasználó nem található!")
      }

      loginUser();
         var username = this.model.username;
         var password = this.model.password;
         
         console.log(username+ " "+password)

        this.loginService.getUserDetails(username,password).subscribe()
           if(this.getData == true){
           this.router.navigate(["/home/"])
           } else {
           alert("Invalid felhasználónév/jelszó");
          }
        }
      }


export class SignUpModel {
  name: string;
  email: string;
  password: string;

  constructor() {
    this.email = "";
    this.name = "";
    this.password = "";
  }
}
function loginUser() {
  throw new Error('Function not implemented.');
}